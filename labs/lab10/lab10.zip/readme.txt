Test permissions
