---
title: "Лабораторная работа №2"
author: "Сако Лассине"
date: "25 сентября 2025 г."
---

# Цель работы
Изучение системы контроля версий Git и приобретение практических навыков работы с GitHub.

# Ход работы

## 1. Настройка GitHub
- Создана учетная запись на GitHub
- Заполнены основные данные профиля

## 2. Базовая настройка Git
```bash
git config --global user.name "Сако Лассине"
git config --global user.email "1032255150@pfur.ru"
git config --global core.quotepath false
git config --global init.defaultBranch master
